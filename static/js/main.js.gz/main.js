    
  $(document).ready(function(){
    $(".open").click(function(){
        
        
        $(".close").show();
       $(".open div").hide();
       $(".").fadeOut("slow");
       $(".list_box").toggle("slow");
      //  $(".head_side").css("padding-top", "200px");
      
   })
      });
 
 
       
  $(document).ready(function(){
    
    $(".icon2 div").click(function(){
       
        $(".icon1 div").show();
       $(".icon2 div").hide();
       $(".packer, .foot_packer").fadeIn("slow");
       $(".list_box").toggle("slow");
      //  $(".head_side").css("padding-top", "0");
     
   })
      });
 